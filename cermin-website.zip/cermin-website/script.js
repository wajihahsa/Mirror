const inputText = document.getElementById("inputText");
const mirrorText = document.getElementById("mirrorText");

inputText.addEventListener("input", function() {
    mirrorText.textContent = inputText.value;
});
