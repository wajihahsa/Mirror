# 🪞 Cermin Digital Website

Project website sederhana bertema **Cermin Digital**.

## ✨ Fitur
- Input teks interaktif
- Efek pantulan seperti cermin
- Desain modern dengan efek blur

## 🚀 Cara Menjalankan
1. Download project ini
2. Extract file zip
3. Buka `index.html` di browser

## 📂 Struktur File
- index.html
- style.css
- script.js
- README.md

---
Dibuat untuk kebutuhan commit GitHub 🚀
